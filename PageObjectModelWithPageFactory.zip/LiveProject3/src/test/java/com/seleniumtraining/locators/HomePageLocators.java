package com.seleniumtraining.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public final class HomePageLocators {

	@FindBy(css = "div.borderM.box.padT20 >div:last-child")
	public WebElement bankManagerLoginButtom;

	@FindBy(css = "button[ng-click='customer()")
	public WebElement customerLoginLoginButtom;
}
