package com.seleniumtraining.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public final class TopNavigationButtonPageLocators {

	@FindBy(css = "div.ng-scope > div > div.box.mainhdr > button.btn.home")
	public WebElement homePageTab;
}
