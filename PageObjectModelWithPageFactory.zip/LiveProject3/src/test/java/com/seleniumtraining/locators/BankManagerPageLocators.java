package com.seleniumtraining.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public final class BankManagerPageLocators {

	@FindBy(css = "button[ng-click='addCust()']")
	public WebElement addCutomerTab;
	@FindBy(css = "input[ng-model='fName']")
	public WebElement firstName;
	@FindBy(css = "input[ng-model='lName']")
	public WebElement lastName;
	@FindBy(css = "input[ng-model='postCd']")
	public WebElement postCode;
	@FindBy(css = "button[class='btn btn-default']")
	public WebElement addCustomerSubmitButton;

	@FindBy(xpath = "//button[@ng-click='openAccount()']")
	public WebElement openAccountTab;
	@FindBy(id = "userSelect")
	public WebElement customerDropdown;
	@FindBy(id = "currency")
	public WebElement currencyDropdown;
	@FindBy(xpath = "//form[@ng-submit='process()']//button")
	public WebElement processButton;
}
