package com.seleniumtraining.pages;

import org.openqa.selenium.support.PageFactory;

import com.seleniumtraining.base.BaseClass;
import com.seleniumtraining.locators.TopNavigationButtonPageLocators;

public class TopNavigationButtonPage extends BaseClass {

	TopNavigationButtonPageLocators topNavigationButtonPageLocators;

	public TopNavigationButtonPage() {
		// This initElements method will create all WebElements
		this.topNavigationButtonPageLocators= PageFactory.initElements(driver, TopNavigationButtonPageLocators.class);

	}

	public void homePageNavigateBack() {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is called.");
		click(topNavigationButtonPageLocators.homePageTab);
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is exited.");
	}

}
