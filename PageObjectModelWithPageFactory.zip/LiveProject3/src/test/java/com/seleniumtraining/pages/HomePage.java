package com.seleniumtraining.pages;

import org.openqa.selenium.support.PageFactory;

import com.seleniumtraining.base.BaseClass;
import com.seleniumtraining.locators.HomePageLocators;

public class HomePage extends BaseClass {

	HomePageLocators homePageLocators;

	public HomePage() {
		// This initElements method will create all WebElements

		this.homePageLocators = PageFactory.initElements(driver, HomePageLocators.class);
		}

	public void gotoCustomerLogin() {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is called.");
		click(homePageLocators.customerLoginLoginButtom);
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is exited.");
	}

	public BankManagerPage gotoBankManagerLogin() {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is called.");
		log.debug("Inside the  method: " + new Throwable().getStackTrace()[0].getMethodName());
		click(homePageLocators.bankManagerLoginButtom);
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is exited.");
		return new BankManagerPage();
	}

	
}
