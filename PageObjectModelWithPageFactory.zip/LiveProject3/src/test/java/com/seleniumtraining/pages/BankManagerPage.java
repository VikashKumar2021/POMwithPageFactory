package com.seleniumtraining.pages;

import java.util.Hashtable;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.seleniumtraining.base.BaseClass;
import com.seleniumtraining.locators.BankManagerPageLocators;

public class BankManagerPage extends BaseClass {

	BankManagerPageLocators bankManagerPageLocators;

	public BankManagerPage() {
		// This initElements method will create all WebElements
		this.bankManagerPageLocators = PageFactory.initElements(driver, BankManagerPageLocators.class);
	}

	public String addCustomer(Hashtable<String, String> data) {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is called.");
		click(bankManagerPageLocators.addCutomerTab);
		type(bankManagerPageLocators.firstName, data.get("firstName"));
		type(bankManagerPageLocators.lastName, data.get("lastName"));
		type(bankManagerPageLocators.postCode, data.get("postCode"));
		String successMessage = null;

		try {
			click(bankManagerPageLocators.addCustomerSubmitButton);
		} catch (Exception e) {
			if (e.toString().contains("org.openqa.selenium.UnhandledAlertException")) {
				Alert alert = driver.switchTo().alert();
				successMessage = alert.getText();
				alert.accept();
			}
		}
		log.debug("Sbumitting the form!!");
		// Alert alert= driver.switchTo().alert();
		// Alert alert = wait.until(ExpectedConditions.alertIsPresent());

		//System.out.println("-------------------------->>>>>>>>>>>>>>>" + successMessage);

		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is exited.");
		return successMessage;
	}

	public String openAccount(Hashtable<String, String> data) {
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is called.");
		log.debug("Inside the test method: " + new Throwable().getStackTrace()[0].getMethodName());
		click(bankManagerPageLocators.openAccountTab);
		select(bankManagerPageLocators.customerDropdown, data.get("customerName"));
		select(bankManagerPageLocators.currencyDropdown, data.get("currency"));
		String successMessage=null;
		try {
			click(bankManagerPageLocators.processButton);
		} catch (Exception e) {
			if (e.toString().contains("org.openqa.selenium.UnhandledAlertException")) {
				Alert alert = driver.switchTo().alert();
				successMessage = alert.getText();
				alert.accept();
			}
		}
		
		log.debug("Sbumitting the form!!");
		// Alert alert= driver.switchTo().alert();
		//Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		log.debug("The page method: " + new Throwable().getStackTrace()[0].getMethodName() + " is exited.");
		return successMessage;
	}

}
