package com.seleniumtraining.testcases;

import java.util.Hashtable;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.seleniumtraining.base.BaseClass;
import com.seleniumtraining.pages.BankManagerPage;
import com.seleniumtraining.pages.HomePage;
import com.seleniumtraining.pages.TopNavigationButtonPage;
import com.seleniumtraining.utilities.TestUtilities;

public class BankManagerOpenAccountTest extends BaseClass{
	
	@Test(dataProviderClass= com.seleniumtraining.utilities.TestUtilities.class, dataProvider = "dp")
	public void bankManagerOpenAccountTest(Hashtable<String, String> data) {
		
		if (!(TestUtilities.isTestRunnable("bankManagerOpenAccountTest", excel))) {

			throw new SkipException("Skipping the test " + "bankManagerLoginTest".toUpperCase() + "as the Run mode is NO");
		}
		log.debug("Inside the test method: " +new Throwable().getStackTrace()[0].getMethodName());
		
		HomePage homePage=  new HomePage();
		BankManagerPage bnkMgrPage=homePage.gotoBankManagerLogin();
		String successMessage=bnkMgrPage.openAccount(data);		
		Assert.assertTrue(successMessage.contains(data.get("alertText")));
		log.debug("Application is submitted successfully with alert message :" + successMessage);
		
		new TopNavigationButtonPage().homePageNavigateBack();
		
		log.debug("Moving out of the test method: " + new Throwable().getStackTrace()[0].getMethodName());
		Reporter.log("Test method " + new Throwable().getStackTrace()[0].getMethodName() + " is executed successfully");
	}

}
