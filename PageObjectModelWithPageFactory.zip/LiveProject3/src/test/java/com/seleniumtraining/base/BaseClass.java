package com.seleniumtraining.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.seleniumtraining.utilities.ExtentReportManager;
import com.seleniumtraining.utilities.ReadExcelUtility;
import com.seleniumtraining.utilities.TestUtilities;

public class BaseClass {
	public static WebDriver driver;
	public static Properties config = new Properties();
	public static FileInputStream fis;
	// Using Logger.getLogger("devpinoyLogger") we create system level logs
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static ReadExcelUtility excel;
	public static WebDriverWait wait;
	public ExtentReports extentReport = ExtentReportManager.getInstance();
	public static ExtentTest extentTest;
	static WebElement dropdown;
	public static String browser;

	public BaseClass() {
		if (driver == null) {
			String log4jConfPath = System.getProperty("user.dir")
					+ "\\src\\test\\resources\\properties\\Log4j.properties";
			PropertyConfigurator.configure(log4jConfPath);
			log.debug("\n\n-------->    Setting up the test suite execution     <-----------\n\n");

			if (driver == null) {

				try {
					fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\"
							+ "Config.properties");
					config.load(fis);
					log.debug("Config file is loaded!!");
				} catch (IOException e) {
					e.printStackTrace();
				}

				
				excel = new ReadExcelUtility(
						System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\testdata.xlsx");
				log.debug("Excel file is loaded!!");

			}
			// for jenkins
			if (System.getenv("browser") != null && !System.getenv().isEmpty()) {
				browser = System.getenv("browser");
			} else {
				browser = config.getProperty("browser");
			}
			config.setProperty("browser", browser);

			if (config.getProperty("browser").equals("chrome")) {
				System.setProperty("webdriver.chrome.driver",
						System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\" + "chromedriver.exe");
				
				DesiredCapabilities dc = new DesiredCapabilities();
				dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
				
				driver = new ChromeDriver(dc);
				log.debug("Chrome Launched!!");
			} else if (config.getProperty("browser").equals("firefox")) {
				System.setProperty("webdriver.gecko.driver",
						System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\" + "geckodriver.exe");

				driver = new FirefoxDriver();
				log.debug("firefox Launched!!");
			} else if (config.getProperty("browser").equals("ie")) {

				System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")
						+ "\\src\\test\\resources\\executables\\" + "IEDriverServer.exe");
				driver = new InternetExplorerDriver();
				System.out.println("_________________________________________________");
				log.debug("IE Launched!!");
			}

			driver.get(config.getProperty("testsiteurl"));
			log.debug("Navigated to test URL :  " + config.getProperty("testsiteurl"));
			driver.manage().window().maximize();
			log.debug("Window maximized");
			driver.manage().deleteAllCookies();
			log.debug("Cookies deleted");
			driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),
					TimeUnit.SECONDS);
			wait = new WebDriverWait(driver, 20);
		}

	}

	@AfterSuite
	public static void tearDown() {

		if (driver != null) {
			driver.quit();
			log.debug("Browser closed!!");
			log.debug("--------------------->    End of test Suite execution     <------------------\n\n");
		}
	}

	// Function to check if element is present on a webpage or not
	public boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	// Function to click on webElement
	public static void click(WebElement element) {
		element.click();
		log.debug("Clicking on an Element : " + element);
		extentTest.log(LogStatus.INFO, "Clicking on:  " + element);
	}

	// Function to send text to webElement
	public static void type(WebElement element, String text) {
		element.sendKeys(text);
		log.debug("Typing in:  " + element + ", entered value as:  " + text);
		extentTest.log(LogStatus.INFO, "Typing in:  " + element + ", entered value as:  " + text);
	}

	// Function to select a value from dropdown
	public static void select(WebElement dropdown, String value) {
		Select select = new Select(dropdown);
		select.selectByVisibleText(value);
		log.debug("Selecting from dropdown:  " + dropdown + ", selected value as:  " + value);
		extentTest.log(LogStatus.INFO, "Selecting from dropdown:  " + dropdown + ", selected value as:  " + value);
	}

	// Soft Assertion implementation to capture screenshot on failure, attach the
	// screenshot in reportNG and extent Report.
	public static void verifyEquals(String expected, String actual) throws IOException {

		try {

			Assert.assertEquals(actual, expected);

		} catch (Throwable t) {
			System.setProperty("org.uncommons.reportng.escape-output", "false");
			TestUtilities.captureScreenshot();
			// ReportNG
			Reporter.log("<br>" + "Verification failure : " + t.getMessage() + "<br>");
			Reporter.log("<a target=\"_blank\" href=" + TestUtilities.screenshotPath + "><img src="
					+ TestUtilities.screenshotPath + " height=200 width=200></img></a>");
			Reporter.log("<br>");
			Reporter.log("<br>");
			// Extent Reports
			extentTest.log(LogStatus.FAIL, " Verification failed with exception : " + t.getMessage());
			extentTest.log(LogStatus.FAIL, extentTest.addScreenCapture(TestUtilities.screenshotPath));

		}

	}
}
